package com.techeats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealboxbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MealboxbackendApplication.class, args);
		System.out.println("TechEats");
	} 
 
}
